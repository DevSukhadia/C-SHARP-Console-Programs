﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace xml_serializing
{
    public class Person
    {
        public int Age { get; set; }

        public string Name { get; set; }

        public List<string> NickNames { get; set; }

        public Person()
        {
            NickNames = new List<string>();
        }
    }
}
