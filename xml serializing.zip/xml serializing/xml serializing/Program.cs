﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace xml_serializing
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.Name = "Alpesh";
            person.Age = 27;
            person.NickNames.Add("Alps");
            person.NickNames.Add("Good Job");

            string xml = GenericSerializer.Serialize(person);
            Console.WriteLine(xml);

            Person deserializedPerson = GenericSerializer.Deserialize<Person>(xml);

            Console.WriteLine("Person name: {0}", deserializedPerson.Name);
            Console.Read();
        }
    }
}
